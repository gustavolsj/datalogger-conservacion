/*----------------------------------------------------------------------------/
  Lovyan GFX - Graphics library for embedded devices.

Original Source:
 https://github.com/lovyan03/LovyanGFX/

Licence:
 [FreeBSD](https://github.com/lovyan03/LovyanGFX/blob/master/license.txt)

Author:
 [lovyan03](https://twitter.com/lovyan03)

Contributors:
 [ciniml](https://github.com/ciniml)
 [mongonta0716](https://github.com/mongonta0716)
 [tobozo](https://github.com/tobozo)
/----------------------------------------------------------------------------*/
#ifndef LGFX_V1_IMPLEMENTATION
#error "Bus_SPI.inl is part of lgfx_v1.cpp and is not meant to be included on its own"
#endif
#if defined (ESP_PLATFORM)
#include <sdkconfig.h>

#if defined (CONFIG_IDF_TARGET_ESP32P4)
 #pragma GCC diagnostic push
 #pragma GCC diagnostic ignored "-Wattributes"
#endif

#include "Bus_SPI.hpp"

#if defined ( CONFIG_IDF_TARGET_ESP32 ) || !defined ( CONFIG_IDF_TARGET )
 #define LGFX_SPIDMA_WORKAROUND
#endif

#include "../../misc/pixelcopy.hpp"

#if __has_include (<soc/dport_reg.h>)
  #include <soc/dport_reg.h>
#endif

#include <driver/rtc_io.h>
#include <esp_heap_caps.h>
#include <esp_log.h>

#if defined (ARDUINO) && (defined (CONFIG_IDF_TARGET_ESP32P4) \
 || defined (CONFIG_IDF_TARGET_ESP32C5) || defined (CONFIG_IDF_TARGET_ESP32C6) \
 || defined (CONFIG_IDF_TARGET_ESP32C61))
 #define LGFX_SPI_CLOCK_TAKEOVER
 #if defined (CONFIG_IDF_TARGET_ESP32P4)
  #include <soc/hp_sys_clkrst_reg.h>
 #else
  #include <soc/pcr_reg.h>
 #endif
#endif

#if __has_include (<esp_private/periph_ctrl.h>)
 #include <esp_private/periph_ctrl.h>
#else
 #include <driver/periph_ctrl.h>
#endif

#if defined (LGFX_SPI_CLOCK_TAKEOVER)
 #if defined (PERIPH_RCC_ATOMIC)
  #define LGFX_SPI_CLOCK_ATOMIC() PERIPH_RCC_ATOMIC()
 #else
  // ESP-IDF 5.1 (arduino-esp32 3.0) has no PERIPH_RCC_ATOMIC(), and its own SPI driver writes the clock
  // source without a lock. A critical section keeps our read-modify-write of the clock register whole.
  static portMUX_TYPE lgfx_spi_clock_mux = portMUX_INITIALIZER_UNLOCKED;
  struct lgfx_spi_clock_section_t
  {
    bool once = true;
    lgfx_spi_clock_section_t(void) { portENTER_CRITICAL(&lgfx_spi_clock_mux); }
    ~lgfx_spi_clock_section_t(void) { portEXIT_CRITICAL(&lgfx_spi_clock_mux); }
  };
  #define LGFX_SPI_CLOCK_ATOMIC() for (lgfx_spi_clock_section_t _lgfx_cs; _lgfx_cs.once; _lgfx_cs.once = false)
 #endif
#endif

#if defined (ARDUINO) // Arduino ESP32
 #include <soc/periph_defs.h>
 #include <esp32-hal-cpu.h>
#endif
#include <driver/spi_master.h>
// IDF 6 exposes the flash-encryption query from efuse rather than esp_flash_encrypt.h.
#if defined ( ESP_IDF_VERSION ) && ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(6, 0, 0) && __has_include(<esp_efuse.h>)
 #include <esp_efuse.h>
 #define LGFX_FLASH_ENCRYPTION_ENABLED() esp_efuse_is_flash_encryption_enabled()
#elif __has_include(<esp_flash_encrypt.h>)
 #include <esp_flash_encrypt.h>
 #define LGFX_FLASH_ENCRYPTION_ENABLED() esp_flash_encryption_enabled()
#else
 #define LGFX_FLASH_ENCRYPTION_ENABLED() true
#endif

#if defined ESP_IDF_VERSION_MAJOR && ESP_IDF_VERSION_MAJOR >= 5
    #include <rom/gpio.h> // dispatched by core
#elif defined ( CONFIG_IDF_TARGET_ESP32S3 ) && __has_include (<esp32s3/rom/gpio.h>)
   #include <esp32s3/rom/gpio.h>  // dispatched by config
#elif defined ( CONFIG_IDF_TARGET_ESP32S2 ) && __has_include (<esp32s2/rom/gpio.h>)
   #include <esp32s2/rom/gpio.h>  // dispatched by config
#elif defined ( CONFIG_IDF_TARGET_ESP32 ) && __has_include (<esp32/rom/gpio.h>)
   #include <esp32/rom/gpio.h>
#else
   #include <rom/gpio.h> // dispatched by core
#endif

#ifndef SPI_PIN_REG
 #define SPI_PIN_REG SPI_MISC_REG
#endif

#if defined (SOC_GDMA_SUPPORTED)  // for C3/C6/C61/S3
 #if __has_include(<soc/gdma_channel.h>)
  #include <soc/gdma_channel.h>
 #elif __has_include(<hal/gdma_channel.h>)
  #pragma GCC diagnostic push
  #pragma GCC diagnostic ignored "-Wattributes"
  #include <hal/gdma_channel.h>
  #pragma GCC diagnostic pop
 #endif
 #if __has_include(<soc/gdma_reg.h>)
  #include <soc/gdma_reg.h>
 #elif __has_include(<soc/axi_dma_reg.h>) // ESP32P4
  #include <soc/axi_dma_reg.h>
  #include <esp_cache.h>
 #elif __has_include(<soc/ahb_dma_reg.h>) // ESP32C61
  #include <soc/ahb_dma_reg.h>
 #endif
 #if __has_include(<soc/gdma_struct.h>)
  #include <soc/gdma_struct.h>
 #elif __has_include(<soc/axi_dma_struct.h>) // ESP32P4
  #include <soc/axi_dma_struct.h>
 #elif __has_include(<soc/ahb_dma_struct.h>) // ESP32C61
  #include <soc/ahb_dma_struct.h>
 #endif
 #if defined AXI_DMA_OUT_LINK1_CH0_REG
  #define DMA_OUT_LINK_CH0_REG       AXI_DMA_OUT_LINK1_CH0_REG
  #define DMA_OUTFIFO_STATUS_CH0_REG AXI_DMA_OUTFIFO_STATUS_CH0_REG
  #define DMA_OUTLINK_START_CH0      AXI_DMA_OUTLINK_START_CH0
  #define DMA_OUTFIFO_EMPTY_CH0      AXI_DMA_OUTFIFO_L3_EMPTY_CH0
  #define DMA_OUT_CONF0_CH0_REG      AXI_DMA_OUT_CONF0_CH0_REG
  #define DMA_OUT_RST_CH0            AXI_DMA_OUT_RST_CH0
  #define SIZE_OF_DMA_OUT_CH (sizeof(axi_dma_out_reg_t))
 #elif defined AHB_DMA_OUT_LINK_CH0_REG
  #define DMA_OUT_LINK_CH0_REG       AHB_DMA_OUT_LINK_CH0_REG
  #define DMA_OUTFIFO_STATUS_CH0_REG AHB_DMA_OUTFIFO_STATUS_CH0_REG
  #define DMA_OUTLINK_START_CH0      AHB_DMA_OUTLINK_START_CH0
  #define DMA_OUTFIFO_EMPTY_CH0      AHB_DMA_OUTFIFO_EMPTY_CH0
  #define DMA_OUT_CONF0_CH0_REG      AHB_DMA_OUT_CONF0_CH0_REG
  #define DMA_OUT_RST_CH0            AHB_DMA_OUT_RST_CH0
  #define SIZE_OF_DMA_OUT_CH (sizeof(AHB_DMA.channel[0]))
  // AHB_DMA 世代のうち C5/C61 は OUT_LINK レジスタが制御ビットのみになり、
  // ディスクリプタアドレスは別レジスタ (チャンネルごとに 4 バイト刻み) へ書く;
  // (同じ AHB_DMA でも H4 はアドレスレジスタをチャンネルブロック内に持つため対象外)
  #if defined (CONFIG_IDF_TARGET_ESP32C5) || defined (CONFIG_IDF_TARGET_ESP32C61)
   #define DMA_OUT_LINK_ADDR_CH0_REG  AHB_DMA_OUT_LINK_ADDR_CH0_REG
  #endif
 #else
  #if __has_include(<soc/gdma_struct.h>)
   #if !defined DMA_OUT_LINK_CH0_REG
    #define DMA_OUT_LINK_CH0_REG       GDMA_OUT_LINK_CH0_REG
    #define DMA_OUTFIFO_STATUS_CH0_REG GDMA_OUTFIFO_STATUS_CH0_REG
    #define DMA_OUTLINK_START_CH0      GDMA_OUTLINK_START_CH0
    #define DMA_OUT_CONF0_CH0_REG      GDMA_OUT_CONF0_CH0_REG
    #define DMA_OUT_RST_CH0            GDMA_OUT_RST_CH0
    #if defined (GDMA_OUTFIFO_EMPTY_L3_CH0)
     #define DMA_OUTFIFO_EMPTY_CH0      GDMA_OUTFIFO_EMPTY_L3_CH0
    #else
     #define DMA_OUTFIFO_EMPTY_CH0      GDMA_OUTFIFO_EMPTY_CH0
    #endif
   #endif
   #define SIZE_OF_DMA_OUT_CH (sizeof(GDMA.channel[0]))
  #endif
 #endif
#endif

#if !defined(gpio_matrix_out) && defined(rom_gpio_matrix_out)
 #define gpio_matrix_out rom_gpio_matrix_out
#endif

#include "common.hpp"

#if defined (CONFIG_IDF_TARGET_ESP32P4)
 #pragma GCC diagnostic pop
#endif

#include <algorithm>

namespace lgfx
{
 inline namespace v1
 {
//----------------------------------------------------------------------------

  // Keep descriptor writes before the register write that starts DMA.
  static inline void dma_desc_fence(void) { __asm__ __volatile__ ("" ::: "memory"); }

#if defined (LGFX_SPI_CLOCK_TAKEOVER)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-variable"
  struct spi_clock_state_t
  {
    uint32_t saved0 = 0;
    uint32_t saved1 = 0;
    const Bus_SPI* owner = nullptr;
    bool active = false;
  };

  static spi_clock_state_t spi_clock_state[SOC_SPI_PERIPH_NUM];

  static bool spi_clock_host_supported(int spi_host)
  {
#if defined (CONFIG_IDF_TARGET_ESP32P4)
    return spi_host == SPI2_HOST || spi_host == SPI3_HOST;
#else
    return spi_host == SPI2_HOST;
#endif
  }

  static uint32_t spi_clock_output_frequency(uint32_t source_hz, uint32_t requested_hz)
  {
    const uint32_t clock_div = FreqToClockDiv(source_hz, requested_hz);
    if (clock_div & SPI_CLK_EQU_SYSCLK) { return source_hz; }
    const uint32_t pre = VALUE_GET_FIELD(clock_div, SPI_CLKDIV_PRE) + 1u;
    const uint32_t n = VALUE_GET_FIELD(clock_div, SPI_CLKCNT_N) + 1u;
    return source_hz / pre / n;
  }

  static uint32_t spi_clock_error(uint32_t actual_hz, uint32_t requested_hz)
  {
    return actual_hz > requested_hz ? actual_hz - requested_hz : requested_hz - actual_hz;
  }

  struct spi_clock_target_t
  {
    uint32_t base_hz;
    uint32_t source_div;
  };

  static spi_clock_target_t spi_clock_find_target(uint32_t requested_hz)
  {
#if defined (CONFIG_IDF_TARGET_ESP32C5) || defined (CONFIG_IDF_TARGET_ESP32C61)
    (void)requested_hz;
    // The 80 MHz root preserves both common write and read rates (for example
    // 40 and 16 MHz), while a 40 MHz root would make 16 MHz inexact.
    return { 80000000u, 2u };
#else
    (void)requested_hz;
    return { 80000000u, 1u };
#endif
  }

  static bool spi_clock_acquire(const Bus_SPI* owner, int spi_host
                              , uint32_t write_hz, uint32_t read_hz)
  {
    if (!spi_clock_host_supported(spi_host) || write_hz == 0 || read_hz == 0) { return false; }

    const auto target = spi_clock_find_target(std::max(write_hz, read_hz));
    const uint32_t current_hz = getSpiClockFrequency(spi_host);
    const uint32_t current_write = spi_clock_output_frequency(current_hz, write_hz);
    const uint32_t target_write = spi_clock_output_frequency(target.base_hz, write_hz);
    const uint32_t target_read = spi_clock_output_frequency(target.base_hz, read_hz);
    const uint32_t current_write_error = spi_clock_error(current_write, write_hz);
    const uint32_t target_write_error = spi_clock_error(target_write, write_hz);
    // Prefer write throughput: a slower read clock is acceptable, but neither
    // clock may exceed its request. Equal write results leave the current owner
    // untouched to avoid an unnecessary source change.
    if (target_write > write_hz || target_read > read_hz
     || target_write_error >= current_write_error)
    {
      return false;
    }

    auto& state = spi_clock_state[spi_host];
    if (state.active) { return false; } // Host-scoped ownership is not nestable.

    // The Arduino bus mutex does not serialize ESP-IDF SPI driver users on the
    // same host; mixing the two APIs cannot provide transaction-wide exclusion.
    LGFX_SPI_CLOCK_ATOMIC()
    {
#if defined (CONFIG_IDF_TARGET_ESP32P4)
      if (spi_host == SPI2_HOST)
      {
        constexpr uint32_t mask = HP_SYS_CLKRST_REG_GPSPI2_CLK_SRC_SEL_M
                                | HP_SYS_CLKRST_REG_GPSPI2_HS_CLK_DIV_NUM_M
                                | HP_SYS_CLKRST_REG_GPSPI2_MST_CLK_DIV_NUM_M;
        constexpr uint32_t target_value = (4u << HP_SYS_CLKRST_REG_GPSPI2_CLK_SRC_SEL_S)
                                        | (2u << HP_SYS_CLKRST_REG_GPSPI2_HS_CLK_DIV_NUM_S)
                                        | (1u << HP_SYS_CLKRST_REG_GPSPI2_MST_CLK_DIV_NUM_S);
        const uint32_t current = REG_READ(HP_SYS_CLKRST_PERI_CLK_CTRL116_REG);
        state.saved0 = current & mask;
        REG_WRITE(HP_SYS_CLKRST_PERI_CLK_CTRL116_REG, (current & ~mask) | target_value);
      }
      else
      {
        constexpr uint32_t source_mask = HP_SYS_CLKRST_REG_GPSPI3_CLK_SRC_SEL_M;
        constexpr uint32_t source_target = 4u << HP_SYS_CLKRST_REG_GPSPI3_CLK_SRC_SEL_S;
        constexpr uint32_t divider_mask = HP_SYS_CLKRST_REG_GPSPI3_HS_CLK_DIV_NUM_M
                                        | HP_SYS_CLKRST_REG_GPSPI3_MST_CLK_DIV_NUM_M;
        constexpr uint32_t divider_target = (2u << HP_SYS_CLKRST_REG_GPSPI3_HS_CLK_DIV_NUM_S)
                                           | (1u << HP_SYS_CLKRST_REG_GPSPI3_MST_CLK_DIV_NUM_S);
        const uint32_t ctrl116 = REG_READ(HP_SYS_CLKRST_PERI_CLK_CTRL116_REG);
        const uint32_t ctrl117 = REG_READ(HP_SYS_CLKRST_PERI_CLK_CTRL117_REG);
        state.saved0 = ctrl116 & source_mask;
        state.saved1 = ctrl117 & divider_mask;
        // Install safe dividers before selecting the 480 MHz source.
        REG_WRITE(HP_SYS_CLKRST_PERI_CLK_CTRL117_REG, (ctrl117 & ~divider_mask) | divider_target);
        REG_WRITE(HP_SYS_CLKRST_PERI_CLK_CTRL116_REG, (ctrl116 & ~source_mask) | source_target);
      }
#elif defined (CONFIG_IDF_TARGET_ESP32C5) || defined (CONFIG_IDF_TARGET_ESP32C61)
      constexpr uint32_t mask = PCR_SPI2_CLKM_SEL_M | PCR_SPI2_CLKM_DIV_NUM_M;
      const uint32_t target_value = (1u << PCR_SPI2_CLKM_SEL_S)
                                  | ((target.source_div - 1u) << PCR_SPI2_CLKM_DIV_NUM_S);
      const uint32_t current = REG_READ(PCR_SPI2_CLKM_CONF_REG);
      state.saved0 = current & mask;
      REG_WRITE(PCR_SPI2_CLKM_CONF_REG, (current & ~mask) | target_value);
#elif defined (CONFIG_IDF_TARGET_ESP32C6)
      constexpr uint32_t mask = PCR_SPI2_CLKM_SEL_M;
      constexpr uint32_t target_value = 1u << PCR_SPI2_CLKM_SEL_S;
      const uint32_t current = REG_READ(PCR_SPI2_CLKM_CONF_REG);
      state.saved0 = current & mask;
      REG_WRITE(PCR_SPI2_CLKM_CONF_REG, (current & ~mask) | target_value);
#endif
      state.owner = owner;
      state.active = true;
    }
    return true;
  }

  static bool spi_clock_owned_by(const Bus_SPI* owner, int spi_host)
  {
    if (!spi_clock_host_supported(spi_host)) { return false; }
    const auto& state = spi_clock_state[spi_host];
    return state.active && state.owner == owner;
  }

  static bool spi_clock_restore(const Bus_SPI* owner, int spi_host)
  {
    if (!spi_clock_host_supported(spi_host)) { return false; }

    auto& state = spi_clock_state[spi_host];
    if (!state.active || state.owner != owner) { return false; }

    LGFX_SPI_CLOCK_ATOMIC()
    {
#if defined (CONFIG_IDF_TARGET_ESP32P4)
      if (spi_host == SPI2_HOST)
      {
        constexpr uint32_t mask = HP_SYS_CLKRST_REG_GPSPI2_CLK_SRC_SEL_M
                                | HP_SYS_CLKRST_REG_GPSPI2_HS_CLK_DIV_NUM_M
                                | HP_SYS_CLKRST_REG_GPSPI2_MST_CLK_DIV_NUM_M;
        const uint32_t current = REG_READ(HP_SYS_CLKRST_PERI_CLK_CTRL116_REG);
        REG_WRITE(HP_SYS_CLKRST_PERI_CLK_CTRL116_REG, (current & ~mask) | state.saved0);
      }
      else
      {
        constexpr uint32_t source_mask = HP_SYS_CLKRST_REG_GPSPI3_CLK_SRC_SEL_M;
        constexpr uint32_t divider_mask = HP_SYS_CLKRST_REG_GPSPI3_HS_CLK_DIV_NUM_M
                                        | HP_SYS_CLKRST_REG_GPSPI3_MST_CLK_DIV_NUM_M;
        const uint32_t ctrl116 = REG_READ(HP_SYS_CLKRST_PERI_CLK_CTRL116_REG);
        const uint32_t ctrl117 = REG_READ(HP_SYS_CLKRST_PERI_CLK_CTRL117_REG);
        // Leave the 480 MHz source before restoring potentially smaller dividers.
        REG_WRITE(HP_SYS_CLKRST_PERI_CLK_CTRL116_REG, (ctrl116 & ~source_mask) | state.saved0);
        REG_WRITE(HP_SYS_CLKRST_PERI_CLK_CTRL117_REG, (ctrl117 & ~divider_mask) | state.saved1);
      }
#elif defined (CONFIG_IDF_TARGET_ESP32C5) || defined (CONFIG_IDF_TARGET_ESP32C61)
      constexpr uint32_t mask = PCR_SPI2_CLKM_SEL_M | PCR_SPI2_CLKM_DIV_NUM_M;
      const uint32_t current = REG_READ(PCR_SPI2_CLKM_CONF_REG);
      REG_WRITE(PCR_SPI2_CLKM_CONF_REG, (current & ~mask) | state.saved0);
#elif defined (CONFIG_IDF_TARGET_ESP32C6)
      constexpr uint32_t mask = PCR_SPI2_CLKM_SEL_M;
      const uint32_t current = REG_READ(PCR_SPI2_CLKM_CONF_REG);
      REG_WRITE(PCR_SPI2_CLKM_CONF_REG, (current & ~mask) | state.saved0);
#endif
      state.active = false;
      state.owner = nullptr;
    }
    return true;
  }
#pragma GCC diagnostic pop

  Bus_SPI::~Bus_SPI(void)
  {
    if (spi_clock_owned_by(this, _cfg.spi_host))
    {
      release();
    }
  }
#endif

  void Bus_SPI::config(const config_t& cfg)
  {
    _cfg = cfg;

    auto spi_port = (uint32_t)(cfg.spi_host) + 1;  // FSPI=1  HSPI=2  VSPI=3;
    _spi_port = spi_port;
    _spi_w0_reg           = reg(SPI_W0_REG(          spi_port));
    _spi_cmd_reg          = reg(SPI_CMD_REG(         spi_port));
    _spi_user_reg         = reg(SPI_USER_REG(        spi_port));
    _spi_mosi_dlen_reg    = reg(SPI_MOSI_DLEN_REG(   spi_port));
#if defined ( SOC_GDMA_SUPPORTED )
#elif defined ( SPI_DMA_STATUS_REG )
    _spi_dma_out_link_reg = reg(SPI_DMA_OUT_LINK_REG(spi_port));
    _spi_dma_outstatus_reg = reg(SPI_DMA_STATUS_REG(spi_port));
#else
    _spi_dma_out_link_reg = reg(SPI_DMA_OUT_LINK_REG(spi_port));
    _spi_dma_outstatus_reg = reg(SPI_DMA_OUTSTATUS_REG(spi_port));
#endif
    if (cfg.pin_dc < 0)
    { // D/Cピン不使用の場合はGPIOレジスタの代わりにダミーとしてmask_reg_dcのアドレスを設定しておく;
      _mask_reg_dc = 0;
      _gpio_reg_dc[0] = &_mask_reg_dc;
      _gpio_reg_dc[1] = &_mask_reg_dc;
    }
    else
    {
      _mask_reg_dc = (1ul << (cfg.pin_dc & 31));
      _gpio_reg_dc[0] = get_gpio_lo_reg(cfg.pin_dc);
      _gpio_reg_dc[1] = get_gpio_hi_reg(cfg.pin_dc);
    }
    _last_freq_apb = 0;

    auto spi_mode = cfg.spi_mode;
    _user_reg = (spi_mode == 1 || spi_mode == 2) ? SPI_CK_OUT_EDGE | SPI_USR_MOSI : SPI_USR_MOSI;
//ESP_LOGI("LGFX","Bus_SPI::config  spi_port:%d  dc:%0d %02x", spi_port, _cfg.pin_dc, _mask_reg_dc);

#if defined LGFX_USE_QSPI
    if( _cfg.pin_io0 != -1 && _cfg.pin_io1 != -1 && _cfg.pin_io2 != -1 && _cfg.pin_io3 != -1 )
    {
      _is_quad_spi = true;
    }
#endif
  }

  void Bus_SPI::dma_channel_reset(void)
  {
#if defined ( DMA_OUT_RST_CH0 )
    if (_spi_dma_out_conf0_reg)
    {
      *_spi_dma_out_conf0_reg = *_spi_dma_out_conf0_reg | DMA_OUT_RST_CH0;
      *_spi_dma_out_conf0_reg = *_spi_dma_out_conf0_reg & ~(uint32_t)DMA_OUT_RST_CH0;
    }
#endif
  }

  bool Bus_SPI::init(void)
  {
//ESP_LOGI("LGFX","Bus_SPI::init");
    dc_control(true);
    pinMode(_cfg.pin_dc, pin_mode_t::output);

    int dma_ch = _cfg.dma_channel;
#if defined (ESP_IDF_VERSION)
 #if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 3, 0)
    dma_ch = dma_ch ? SPI_DMA_CH_AUTO : SPI_DMA_DISABLED;
 #endif
#endif

#if defined LGFX_USE_QSPI
    if( _is_quad_spi )
      _inited = spi::initQuad(_cfg.spi_host, _cfg.pin_sclk, _cfg.pin_io0, _cfg.pin_io1, _cfg.pin_io2, _cfg.pin_io3, dma_ch).has_value();
    else
#endif
      _inited = spi::init(_cfg.spi_host, _cfg.pin_sclk, _cfg.pin_miso, _cfg.pin_mosi, dma_ch).has_value();

#if defined ( SOC_GDMA_SUPPORTED ) && defined ( DMA_OUT_LINK_CH0_REG )
    // 割当られたDMAチャネル番号を取得する

#if defined ( SOC_GDMA_TRIG_PERIPH_SPI3 )
    int peri_sel = (_spi_port == 3) ? SOC_GDMA_TRIG_PERIPH_SPI3 : SOC_GDMA_TRIG_PERIPH_SPI2;
#else
    int peri_sel = SOC_GDMA_TRIG_PERIPH_SPI2;
#endif

    int assigned_dma_ch = search_dma_out_ch(peri_sel);

    if (assigned_dma_ch >= 0)
    { // DMAチャンネルが特定できたらそれを使用する;
      _spi_dma_out_link_reg  = reg(DMA_OUT_LINK_CH0_REG       + assigned_dma_ch * SIZE_OF_DMA_OUT_CH);
      _spi_dma_outstatus_reg = reg(DMA_OUTFIFO_STATUS_CH0_REG + assigned_dma_ch * SIZE_OF_DMA_OUT_CH);
      #if defined ( DMA_OUT_CONF0_CH0_REG )
      _spi_dma_out_conf0_reg = reg(DMA_OUT_CONF0_CH0_REG      + assigned_dma_ch * SIZE_OF_DMA_OUT_CH);
      #endif
      #if defined ( LGFX_PSRAM_DMA_CAPABLE ) && !(defined ( SOC_AHB_GDMA_VERSION ) && SOC_AHB_GDMA_VERSION == 1)
      // Encrypted external RAM requires 16-byte address and length alignment on AHB v2 / AXI.
      _psram_dma_ok = !LGFX_FLASH_ENCRYPTION_ENABLED();
      #endif
      #if defined ( CONFIG_IDF_TARGET_ESP32P4 )
      _spi_dma_out_link2_reg = reg(AXI_DMA_OUT_LINK2_CH0_REG  + assigned_dma_ch * SIZE_OF_DMA_OUT_CH);
      #elif defined ( DMA_OUT_LINK_ADDR_CH0_REG )
      _spi_dma_out_link2_reg = reg(DMA_OUT_LINK_ADDR_CH0_REG  + assigned_dma_ch * sizeof(uint32_t));
      #endif
    }
#elif defined ( CONFIG_IDF_TARGET_ESP32 ) || !defined ( CONFIG_IDF_TARGET )

    dma_ch = (*reg(DPORT_SPI_DMA_CHAN_SEL_REG) >> (_cfg.spi_host * 2)) & 3;
    // ESP_LOGE("LGFX", "SPI_HOST: %d / DMA_CH: %d", _cfg.spi_host, dma_ch);

#endif

    _dma_ch = dma_ch;

    return _inited;
  }

  static void gpio_reset(size_t pin)
  {
    if (pin >= GPIO_NUM_MAX) return;
    gpio_reset_pin( (gpio_num_t)pin);
#if defined (ESP_IDF_VERSION_VAL) && (ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(6, 0, 0))
    rom_gpio_matrix_out((gpio_num_t)pin, SIG_GPIO_OUT_IDX, 0, 0);
#else
    gpio_matrix_out((gpio_num_t)pin, SIG_GPIO_OUT_IDX, 0, 0);
#endif
    // gpio_matrix_in には、ArduinoESP32 v1.0.x系では重大なバグがある。(無関係なピンに対して設定変更が行われることがある)
    // gpio_matrix_in( (gpio_num_t)pin, 0x100, 0   );
  }

  void Bus_SPI::release(void)
  {
//ESP_LOGI("LGFX","Bus_SPI::release");
#if defined (LGFX_SPI_CLOCK_TAKEOVER)
    if (spi_clock_owned_by(this, _cfg.spi_host))
    {
      // An active takeover implies this instance still owns the Arduino bus
      // mutex.  Finish the transfer and restore the host before releasing it.
      dc_control(true);
      if (spi_clock_restore(this, _cfg.spi_host))
      {
        spi::endTransaction(_cfg.spi_host);
      }
    }
#endif
    if (!_inited) return;
    _inited = false;
    spi::release(_cfg.spi_host);
    gpio_reset(_cfg.pin_dc  );

#if defined LGFX_USE_QSPI
    if(_is_quad_spi)
    {
      gpio_reset(_cfg.pin_io0);
      gpio_reset(_cfg.pin_io1);
      gpio_reset(_cfg.pin_io2);
      gpio_reset(_cfg.pin_io3);
    }
    else
#endif
    {
      gpio_reset(_cfg.pin_mosi);
      gpio_reset(_cfg.pin_miso);
      gpio_reset(_cfg.pin_sclk);
    }

  }

  void Bus_SPI::beginTransaction(void)
  {
//ESP_LOGI("LGFX","Bus_SPI::beginTransaction");
    // Bus acquisition can change the SPI source or its pre-dividers.
    if (_cfg.use_lock)
    {
      spi::beginTransaction(_cfg.spi_host);
#if defined (LGFX_SPI_CLOCK_TAKEOVER)
      spi_clock_acquire(this, _cfg.spi_host, _cfg.freq_write, _cfg.freq_read);
#endif
    }
    uint32_t freq_apb = getSpiClockFrequency(_cfg.spi_host);
    uint32_t clkdiv_write = _clkdiv_write;
    if (_last_freq_apb != freq_apb)
    {
      _last_freq_apb = freq_apb;
      _clkdiv_read = FreqToClockDiv(freq_apb, _cfg.freq_read);
      clkdiv_write = FreqToClockDiv(freq_apb, _cfg.freq_write);
      _clkdiv_write = clkdiv_write;
      dc_control(true);
      pinMode(_cfg.pin_dc, pin_mode_t::output);
    }

    auto spi_mode = _cfg.spi_mode;
    uint32_t pin = (spi_mode & 2) ? SPI_CK_IDLE_EDGE : 0;
    pin = pin
#if defined ( SPI_CS0_DIS )
            | SPI_CS0_DIS
#endif
#if defined ( SPI_CS1_DIS )
            | SPI_CS1_DIS
#endif
#if defined ( SPI_CS2_DIS )
            | SPI_CS2_DIS
#endif
#if defined ( SPI_CS3_DIS )
            | SPI_CS3_DIS
#endif
#if defined ( SPI_CS4_DIS )
            | SPI_CS4_DIS
#endif
#if defined ( SPI_CS5_DIS )
            | SPI_CS5_DIS
#endif
    ;

    *_spi_user_reg = _user_reg;
    auto spi_port = _spi_port;
    (void)spi_port;
    writereg(SPI_PIN_REG(spi_port), pin);
    writereg(SPI_CLOCK_REG(spi_port), clkdiv_write);
#if defined ( SPI_UPDATE )
    *_spi_cmd_reg = SPI_UPDATE;
#endif
  }

  void Bus_SPI::endTransaction(void)
  {
    dc_control(true);
#if defined ( LGFX_SPIDMA_WORKAROUND )
    if (_dma_ch) { spicommon_dmaworkaround_idle(_dma_ch); }
#endif
#if defined (LGFX_SPI_CLOCK_TAKEOVER)
    if (_cfg.use_lock) { spi_clock_restore(this, _cfg.spi_host); }
#endif
#if defined (ARDUINO) // Arduino ESP32
    *_spi_user_reg = SPI_USR_MOSI | SPI_USR_MISO | SPI_DOUTDIN; // for other SPI device (e.g. SD card)
#endif
    if (_cfg.use_lock) spi::endTransaction(_cfg.spi_host);
  }

  void Bus_SPI::wait(void)
  {
    auto spi_cmd_reg = _spi_cmd_reg;
    while (*spi_cmd_reg & SPI_USR);
  }

  bool Bus_SPI::busy(void) const
  {
    return (*_spi_cmd_reg & SPI_USR);
  }

  bool Bus_SPI::writeCommand(uint32_t data, uint_fast8_t bit_length)
  {
//ESP_LOGI("LGFX","writeCmd: %02x  len:%d   dc:%02x", data, bit_length, _mask_reg_dc);
    --bit_length;
    auto spi_mosi_dlen_reg = _spi_mosi_dlen_reg;
    auto spi_w0_reg = _spi_w0_reg;
    auto spi_cmd_reg = _spi_cmd_reg;
    auto gpio_reg_dc = _gpio_reg_dc[0];
    auto mask_reg_dc = _mask_reg_dc;

#if defined LGFX_USE_QSPI
    // reg for sending data in 1-bit mode
    auto qspi_user_reg = _spi_user_reg;
    uint32_t qspi_user = (*qspi_user_reg & (~SPI_FWRITE_QUAD));
#endif

#if !defined ( CONFIG_IDF_TARGET ) || defined ( CONFIG_IDF_TARGET_ESP32 )
    while (*spi_cmd_reg & SPI_USR) {}    // wait SPI
#else
    auto dma = _clear_dma_reg;
    if (dma)
    {
      _clear_dma_reg = nullptr;
      while (*spi_cmd_reg & SPI_USR) {}    // wait SPI
      *dma = 0;
    }
    else
    {
      while (*spi_cmd_reg & SPI_USR) {}    // wait SPI
    }
#endif

#if defined LGFX_USE_QSPI
    if( _is_quad_spi)
      *qspi_user_reg = qspi_user;
#endif
    *spi_mosi_dlen_reg = bit_length;   // set bitlength
    *spi_w0_reg = data;                // set data
    *gpio_reg_dc = mask_reg_dc;        // D/C
    *spi_cmd_reg = SPI_EXECUTE;        // exec SPI
    return true;
  }

  void Bus_SPI::writeData(uint32_t data, uint_fast8_t bit_length)
  {
//ESP_LOGI("LGFX","writeData: %02x  len:%d", data, bit_length);
    --bit_length;
    auto spi_mosi_dlen_reg = _spi_mosi_dlen_reg;
    auto spi_w0_reg = _spi_w0_reg;
    auto spi_cmd_reg = _spi_cmd_reg;
    auto gpio_reg_dc = _gpio_reg_dc[1];
    auto mask_reg_dc = _mask_reg_dc;

#if defined LGFX_USE_QSPI
    // reg for sending data in 4-bit mode
    auto qspi_user_reg = _spi_user_reg;
    uint32_t qspi_user = (*qspi_user_reg | SPI_FWRITE_QUAD);
#endif

#if !defined ( CONFIG_IDF_TARGET ) || defined ( CONFIG_IDF_TARGET_ESP32 )
    while (*spi_cmd_reg & SPI_USR) {}    // wait SPI
#else
    auto dma = _clear_dma_reg;
    if (dma)
    {
      _clear_dma_reg = nullptr;
      while (*spi_cmd_reg & SPI_USR) {}    // wait SPI
      *dma = 0;
    }
    else
    {
      while (*spi_cmd_reg & SPI_USR) {}    // wait SPI
    }
#endif
#if defined LGFX_USE_QSPI
    if( _is_quad_spi)
      *qspi_user_reg = qspi_user;
#endif
    *spi_mosi_dlen_reg = bit_length;   // set bitlength
    *spi_w0_reg = data;                // set data
    *gpio_reg_dc = mask_reg_dc;        // D/C
    *spi_cmd_reg = SPI_EXECUTE;        // exec SPI
  }

  void Bus_SPI::writeDataRepeat(uint32_t data, uint_fast8_t bit_length, uint32_t count)
  {
    auto spi_mosi_dlen_reg = _spi_mosi_dlen_reg;
    auto spi_w0_reg = _spi_w0_reg;
    auto spi_cmd_reg = _spi_cmd_reg;
    auto gpio_reg_dc = _gpio_reg_dc[1];
    auto mask_reg_dc = _mask_reg_dc;

#if defined LGFX_USE_QSPI
    // reg for sending data in 4-bit mode
    auto qspi_user_reg = _spi_user_reg;
    uint32_t qspi_user = (_user_reg & ~(SPI_USR_MISO | SPI_DOUTDIN | SPI_SIO)) | SPI_USR_MOSI | SPI_FWRITE_QUAD;
#endif

#if defined ( CONFIG_IDF_TARGET ) && !defined ( CONFIG_IDF_TARGET_ESP32 )
    auto dma = _clear_dma_reg;
    if (dma) { _clear_dma_reg = nullptr; }
#endif
    if (1 == count)
    {
      --bit_length;
      while (*spi_cmd_reg & SPI_USR);    // wait SPI
#if defined ( CONFIG_IDF_TARGET ) && !defined ( CONFIG_IDF_TARGET_ESP32 )
      if (dma) { *dma = 0; }
#endif
#if defined LGFX_USE_QSPI
      if( _is_quad_spi)
        *qspi_user_reg = qspi_user;
#endif
      *gpio_reg_dc = mask_reg_dc;        // D/C high (data)
      *spi_mosi_dlen_reg = bit_length;   // set bitlength
      *spi_w0_reg = data;                // set data
      *spi_cmd_reg = SPI_EXECUTE;        // exec SPI
      return;
    }

    uint32_t regbuf0 = data | data << bit_length;
    uint32_t regbuf1;
    uint32_t regbuf2;
    // make 12Bytes data.
    bool bits24 = (bit_length == 24);
    if (bits24) {
      regbuf1 = regbuf0 >> 8 | regbuf0 << 16;
      regbuf2 = regbuf0 >>16 | regbuf0 <<  8;
    } else {
      if (bit_length == 8) { regbuf0 |= regbuf0 << 16; }
      regbuf1 = regbuf0;
      regbuf2 = regbuf0;
    }

    uint32_t length = bit_length * count;          // convert to bitlength.
    uint32_t len = (length <= 96u) ? length : (length <= 144u) ? 48u : 96u; // 1st send length = max 12Byte (96bit).

    length -= len;
    --len;

    while (*spi_cmd_reg & SPI_USR) {}  // wait SPI
#if defined ( CONFIG_IDF_TARGET ) && !defined ( CONFIG_IDF_TARGET_ESP32 )
    if (dma) { *dma = 0; }
#endif
#if defined LGFX_USE_QSPI
    if( _is_quad_spi)
      *qspi_user_reg = qspi_user;
#endif
    *gpio_reg_dc = mask_reg_dc;      // D/C high (data)
    *spi_mosi_dlen_reg = len;
    // copy to SPI buffer register
    spi_w0_reg[0] = regbuf0;
    spi_w0_reg[1] = regbuf1;
    spi_w0_reg[2] = regbuf2;
    *spi_cmd_reg = SPI_EXECUTE;      // exec SPI
    if (0 == length) return;

    uint32_t regbuf[7] = { regbuf0, regbuf1, regbuf2, regbuf0, regbuf1, regbuf2, regbuf0 } ;

    // copy to SPI buffer register
    memcpy((void*)&spi_w0_reg[3], regbuf, 24);
    memcpy((void*)&spi_w0_reg[9], regbuf, 28);

    // limit = 64Byte / depth_bytes;
    // When 24bit color, 504 bits out of 512bit buffer are used.
    // When 16bit color, it uses exactly 512 bytes. but, it behaves like a ring buffer, can specify a larger size.
    uint32_t limit;
    if (bits24)
    {
      limit = 504;
      len = length % limit;
    }
    else
    {
#if defined ( CONFIG_IDF_TARGET_ESP32 )
      limit = (1 << 11);
#else
      limit = (1 << 9);
#endif
      len = length & (limit - 1);
    }

    if (len)
    {
      length -= len;
      --len;
      while (*spi_cmd_reg & SPI_USR);
      *spi_mosi_dlen_reg = len;
      *spi_cmd_reg = SPI_EXECUTE;
      if (0 == length) return;
    }

    while (*spi_cmd_reg & SPI_USR);
    *spi_mosi_dlen_reg = limit - 1;
    *spi_cmd_reg = SPI_EXECUTE;
    while (length -= limit)
    {
      while (*spi_cmd_reg & SPI_USR);
      *spi_cmd_reg = SPI_EXECUTE;
    }
  }

  void Bus_SPI::writePixels(pixelcopy_t* param, uint32_t length)
  {

#if defined LGFX_USE_QSPI
    if( _is_quad_spi)
    {
      // reg for sending data in 4-bit mode
      auto qspi_user_reg = _spi_user_reg;
      uint32_t qspi_user = (_user_reg & ~(SPI_USR_MISO | SPI_DOUTDIN | SPI_SIO)) | SPI_USR_MOSI | SPI_FWRITE_QUAD;
      *qspi_user_reg = qspi_user;
    }
#endif

    const uint8_t bytes = param->dst_bits >> 3;
    if (_cfg.dma_channel)
    {
      uint32_t limit = (bytes == 2) ? 32 : 24;
      uint32_t len;
      do
      {
        len = (limit << 1) <= length ? limit : length;
        if (limit <= 256) limit <<= 1;
        auto dmabuf = _flip_buffer.getBuffer(len * bytes);
        if (dmabuf == nullptr) {
          break;
        }
        param->fp_copy(dmabuf, 0, len, param);
        writeBytes(dmabuf, len * bytes, true, true);
      } while (length -= len);
      if (length == 0) return;
    }

/// ESP32-C3 で HIGHPART を使用すると異常動作するため分岐する;
#if defined ( SPI_UPDATE )  // for C3/S3

    const uint32_t limit = (bytes == 2) ? 32 : 21;
    uint32_t l = (length - 1) / limit;
    uint32_t len = length - (l * limit);
    length = l;
    uint32_t regbuf[16];
    param->fp_copy(regbuf, 0, len, param);

    auto spi_w0_reg = _spi_w0_reg;

    dc_control(true);
    set_write_len(len * bytes << 3);

    memcpy((void*)spi_w0_reg, regbuf, (len * bytes + 3) & (~3));

    exec_spi();
    if (0 == length) return;


    param->fp_copy(regbuf, 0, limit, param);
    wait_spi();
    set_write_len(limit * bytes << 3);
    memcpy((void*)spi_w0_reg, regbuf, limit * bytes);
    exec_spi();


    while (--length)
    {
      param->fp_copy(regbuf, 0, limit, param);
      wait_spi();
      memcpy((void*)spi_w0_reg, regbuf, limit * bytes);
      exec_spi();
    }

#else

    const uint32_t limit = (bytes == 2) ? 16 : 10; //  limit = 32/bytes (bytes==2 is 16   bytes==3 is 10)
    uint32_t len = (length - 1) / limit;
    uint32_t highpart = (len & 1) << 3;
    len = length - (len * limit);
    uint32_t regbuf[8];
    param->fp_copy(regbuf, 0, len, param);

    auto spi_w0_reg = _spi_w0_reg;

    uint32_t user_reg = *_spi_user_reg;

    dc_control(true);
    set_write_len(len * bytes << 3);

    memcpy((void*)&spi_w0_reg[highpart], regbuf, (len * bytes + 3) & (~3));
    if (highpart) *_spi_user_reg = user_reg | SPI_USR_MOSI_HIGHPART;
    exec_spi();
    if (0 == (length -= len)) return;

    for (; length; length -= limit)
    {
      param->fp_copy(regbuf, 0, limit, param);
      memcpy((void*)&spi_w0_reg[highpart ^= 0x08], regbuf, limit * bytes);
      uint32_t user = user_reg;
      if (highpart) user |= SPI_USR_MOSI_HIGHPART;
      if (len != limit)
      {
        len = limit;
        wait_spi();
        set_write_len(limit * bytes << 3);
        *_spi_user_reg = user;
        exec_spi();
      }
      else
      {
        wait_spi();
        *_spi_user_reg = user;
        exec_spi();
      }
    }

#endif

  }

  void Bus_SPI::writeBytes(const uint8_t* data, uint32_t length, bool dc, bool use_dma)
  {
#if defined LGFX_USE_QSPI
    if( _is_quad_spi)
    {
      // reg for sending data in 4-bit mode
      auto qspi_user_reg = _spi_user_reg;
      uint32_t qspi_user = (_user_reg & ~(SPI_USR_MISO | SPI_DOUTDIN | SPI_SIO)) | SPI_USR_MOSI | SPI_FWRITE_QUAD;
      *qspi_user_reg = qspi_user;
    }
#endif

    if (length <= 64)
    {
      auto spi_w0_reg = _spi_w0_reg;
      auto aligned_len = (length + 3) & (~3);
      length <<= 3;
      dc_control(dc);
      set_write_len(length);
#if defined ( CONFIG_IDF_TARGET_ESP32P4 )
// P4のペリフェラルレジスタへのmemcpyはうまく動作しないので処理を分岐する
      for (int i = 0; i < aligned_len >> 2; ++i) {
        spi_w0_reg[i] = ((uint32_t*)data)[i];
      }
#else
      memcpy((void*)spi_w0_reg, data, aligned_len);
#endif
      exec_spi();
      return;
    }

    if (_cfg.dma_channel)
    {
      if (false == use_dma && length < 1024)
      {
        auto buf = _flip_buffer.getBuffer(length);
        if (buf) {
          memcpy(buf, data, length);
          data = buf;
          use_dma = true;
        }
      }
      if (use_dma)
      {
        // heap_capable_dma() tests internal RAM; preserve the SPI external-RAM path below.
        if (!heap_capable_dma(data)
#if defined ( LGFX_PSRAM_DMA_CAPABLE )
         && !esp_ptr_external_ram(data)
#endif
           ) { writeBytes(data, length, dc, false); return; }
#if defined ( LGFX_PSRAM_DMA_CAPABLE )
        // A short head before the next 64-byte boundary can stall GDMA on ESP32-S3.
        if (esp_ptr_external_ram(data))
        {
          uint32_t head = (uint32_t)(-(intptr_t)data) & (dma_ext_align - 1);
          if (!_psram_dma_ok || head >= length || length - head < dma_ext_align) { writeBytes(data, length, dc, false); return; }
          // Write back before the head goes out: a write-back between the head and the DMA (up to
          // ~0.6 ms for a dirty 300 KB sprite on ESP32-P4) stalls the bus mid-transfer, at a byte
          // offset set by the buffer address rather than by pixel boundaries. Panels that buffer
          // pixels (the Module Display FPGA) mis-handle that stall.
          dma_cache_sync(data + head, length - head);
          if (head)
          {
            writeBytes(data, head, dc, false);
            data += head;
            length -= head;
          }
        }
#endif
        auto spi_dma_out_link_reg = _spi_dma_out_link_reg;
        #if defined ( CONFIG_IDF_TARGET_ESP32P4 ) || defined ( DMA_OUT_LINK_ADDR_CH0_REG )
        auto spi_dma_out_link2_reg = _spi_dma_out_link2_reg;
        #endif
        auto cmd = _spi_cmd_reg;
        while (*cmd & SPI_USR) {}
        *spi_dma_out_link_reg = 0;
        _setup_dma_desc_links(data, length);

        #if defined ( CONFIG_IDF_TARGET_ESP32P4 )
        if (!esp_ptr_external_ram(data))   // external RAM was written back above
        {
          esp_cache_msync((void*)data, sizeof(uint8_t) * length, ESP_CACHE_MSYNC_FLAG_DIR_C2M | ESP_CACHE_MSYNC_FLAG_UNALIGNED);
        }
        esp_cache_msync(_dmadesc, sizeof(dma_desc_t) * _dmadesc_size, ESP_CACHE_MSYNC_FLAG_DIR_C2M | ESP_CACHE_MSYNC_FLAG_UNALIGNED);
        #endif
#if defined ( SOC_GDMA_SUPPORTED ) && defined ( DMA_OUTLINK_START_CH0 )
        dma_channel_reset();
        auto dma = reg(SPI_DMA_CONF_REG(_spi_port));
        *dma = 0; /// Clear previous transfer
#if defined ( SPI_DMA_AFIFO_RST ) && defined ( SPI_BUF_AFIFO_RST ) && defined ( SPI_RX_AFIFO_RST )
        *dma = SPI_DMA_AFIFO_RST | SPI_BUF_AFIFO_RST | SPI_RX_AFIFO_RST;
#endif
        uint32_t len = ((length - 1) & ((SPI_MS_DATA_BITLEN)>>3)) + 1;
        #if defined ( CONFIG_IDF_TARGET_ESP32P4 ) || defined ( DMA_OUT_LINK_ADDR_CH0_REG )
        *spi_dma_out_link2_reg = ((uint32_t)(_dmadesc));
        *spi_dma_out_link_reg = DMA_OUTLINK_START_CH0 ;
        #else
        *spi_dma_out_link_reg = DMA_OUTLINK_START_CH0 | ((int)(&_dmadesc[0]) & 0xFFFFF);
        #endif
        *dma = SPI_DMA_TX_ENA;
        _clear_dma_reg = dma;
        set_write_len(len << 3);
        *_gpio_reg_dc[dc] = _mask_reg_dc;

        // DMA準備完了待ち;
 #if defined ( DMA_OUTFIFO_EMPTY_CH0 )
        while (*_spi_dma_outstatus_reg & DMA_OUTFIFO_EMPTY_CH0 ) {}
 #endif
        exec_spi();

        if (length -= len)
        {
          while (*cmd & SPI_USR) {}
          set_write_len(SPI_MS_DATA_BITLEN + 1);
          goto label_start;
          do
          {
            vTaskDelay(1 / portTICK_PERIOD_MS);
            while (*cmd & SPI_USR) {}
label_start:
            exec_spi();
          } while (length -= ((SPI_MS_DATA_BITLEN + 1) >> 3));
        }
#elif defined ( CONFIG_IDF_TARGET_ESP32 ) || !defined ( CONFIG_IDF_TARGET )
        auto dma_conf_reg = reg(SPI_DMA_CONF_REG(_spi_port));
        auto dma_conf = *dma_conf_reg & ~(SPI_OUT_DATA_BURST_EN | SPI_AHBM_RST | SPI_AHBM_FIFO_RST | SPI_OUT_RST);
        *dma_conf_reg = dma_conf | SPI_AHBM_RST | SPI_AHBM_FIFO_RST | SPI_OUT_RST;

        // 送信長が4の倍数の場合のみバーストモードを使用する
        // ※ 以下の3つの条件が揃うと、DMA転送の末尾付近でデータが化ける現象が起きる。
        //    1.送信クロック80MHz (APBクロックと1:1)
        //    2.DMAバースト読出し有効
        //    3.送信データ長が4の倍数ではない (1Byte~3Byteの端数がある場合)
        dma_conf |= (length & 3) ? (SPI_OUTDSCR_BURST_EN) : (SPI_OUTDSCR_BURST_EN | SPI_OUT_DATA_BURST_EN);

        *dma_conf_reg = dma_conf;
        uint32_t len = length;
        *spi_dma_out_link_reg = SPI_OUTLINK_START | ((int)(&_dmadesc[0]) & 0xFFFFF);
        _clear_dma_reg = spi_dma_out_link_reg;
        set_write_len(len << 3);
        *_gpio_reg_dc[dc] = _mask_reg_dc;

        // DMA準備完了待ち;
 #if defined (SPI_DMA_OUTFIFO_EMPTY)
        while (*_spi_dma_outstatus_reg & SPI_DMA_OUTFIFO_EMPTY ) {}
 #else
  #if defined ( LGFX_SPIDMA_WORKAROUND )
        if (_dma_ch) { spicommon_dmaworkaround_transfer_active(_dma_ch); }
  #endif
 #endif
        exec_spi();
#endif
        return;
      }
    }

    auto spi_w0_reg = _spi_w0_reg;

/// ESP32-C3 で HIGHPART を使用すると異常動作するため分岐する;
#if defined ( SPI_UPDATE )  // for C3/S3

    uint32_t regbuf[16];
    constexpr uint32_t limit = 64;
    uint32_t len = ((length - 1) & 0x3F) + 1;

    memcpy(regbuf, data, len);
    dc_control(dc);
    set_write_len(len << 3);

    for (int i = 0; i < (len + 3) >> 2; ++i) {
      spi_w0_reg[i] = regbuf[i];
    }

    exec_spi();
    if (0 == (length -= len)) return;

    data += len;
    memcpy(regbuf, data, limit);
    wait_spi();
    set_write_len(limit << 3);
    for (int i = 0; i < limit >> 2; ++i) {
      spi_w0_reg[i] = regbuf[i];
    }

    exec_spi();
    if (0 == (length -= limit)) return;

    do
    {
      data += limit;
      memcpy(regbuf, data, limit);
      wait_spi();
      for (int i = 0; i < limit >> 2; ++i) {
        spi_w0_reg[i] = regbuf[i];
      }
      exec_spi();
    } while (0 != (length -= limit));

#else

    constexpr uint32_t limit = 32;
    uint32_t len = ((length - 1) & 0x1F) + 1;
    uint32_t highpart = ((length - 1) & limit) >> 2; // 8 or 0

    uint32_t user_reg = _user_reg;

    if( _is_quad_spi)
      user_reg = user_reg | SPI_FWRITE_QUAD;

    dc_control(dc);
    set_write_len(len << 3);

    memcpy((void*)&spi_w0_reg[highpart], data, (len + 3) & (~3));
    if (highpart) *_spi_user_reg = user_reg | SPI_USR_MOSI_HIGHPART;
    exec_spi();
    if (0 == (length -= len)) return;

    for (; length; length -= limit)
    {
      data += len;
      memcpy((void*)&spi_w0_reg[highpart ^= 0x08], data, limit);
      uint32_t user = user_reg;
      if (highpart) user |= SPI_USR_MOSI_HIGHPART;
      if (len != limit)
      {
        len = limit;
        wait_spi();
        set_write_len(limit << 3);
        *_spi_user_reg = user;
        exec_spi();
      }
      else
      {
        wait_spi();
        *_spi_user_reg = user;
        exec_spi();
      }
    }

#endif

  }

  void Bus_SPI::addDMAQueue(const uint8_t* data, uint32_t length)
  {
    if (!_cfg.dma_channel)
    {
      writeBytes(data, length, true, true);
      return;
    }

    // Drain queued descriptors before CPU output; writeBytes() may reuse their flip buffer.
    // External RAM remains eligible only when this SPI bus can DMA it without flash encryption.
    if (!heap_capable_dma(data)
#if defined ( LGFX_PSRAM_DMA_CAPABLE )
     && !(_psram_dma_ok && esp_ptr_external_ram(data))
#endif
       )
    {
      execDMAQueue();
      wait();
      writeBytes(data, length, true, false);
      return;
    }
    // A queued source must not be changed after submission.
#if defined ( CONFIG_IDF_TARGET_ESP32P4 )
    esp_cache_msync((void*)data, length, ESP_CACHE_MSYNC_FLAG_DIR_C2M | ESP_CACHE_MSYNC_FLAG_UNALIGNED);
#else
    dma_cache_sync(data, length);
#endif

    _dma_queue_bytes += length;
    size_t index = _dma_queue_size;
    size_t new_size = index + ((length-1) / SPI_MAX_DMA_LEN) + 1;

    if (_dma_queue_capacity < new_size)
    {
      _dma_queue_capacity = new_size + 8;
      auto new_queue = (dma_desc_t*)heap_caps_malloc(sizeof(dma_desc_t) * _dma_queue_capacity, MALLOC_CAP_DMA);
      if (index)
      {
        memcpy(new_queue, _dma_queue, sizeof(dma_desc_t) * index);
      }
      if (_dma_queue != nullptr) { heap_free(_dma_queue); }
      _dma_queue = new_queue;
    }
    _dma_queue_size = new_size;
    dma_desc_t *dmadesc = &_dma_queue[index];

    while (length > SPI_MAX_DMA_LEN)
    {
      *(uint32_t*)dmadesc = SPI_MAX_DMA_LEN | SPI_MAX_DMA_LEN << 12 | 0x80000000;
      dmadesc->buffer = const_cast<uint8_t*>(data);
      dmadesc++;
      data += SPI_MAX_DMA_LEN;
      length -= SPI_MAX_DMA_LEN;
    }
    *(uint32_t*)dmadesc = ((length + 3) & ( ~3 )) | length << 12 | 0x80000000;
    dmadesc->buffer = const_cast<uint8_t*>(data);
  }

  void Bus_SPI::execDMAQueue(void)
  {
    if (0 == _dma_queue_size) return;

#if defined LGFX_USE_QSPI
    if( _is_quad_spi)
    {
      // reg for sending data in 4-bit mode
      auto qspi_user_reg = _spi_user_reg;
      uint32_t qspi_user = (_user_reg & ~(SPI_USR_MISO | SPI_DOUTDIN | SPI_SIO)) | SPI_USR_MOSI | SPI_FWRITE_QUAD;
      *qspi_user_reg = qspi_user;
    }
#endif

    int index = _dma_queue_size - 1;
    _dma_queue_size = 0;
    _dma_queue[index].dw0.suc_eof = 1;
    _dma_queue[index].next = nullptr;
    while (--index >= 0)
    {
      _dma_queue[index].next = &_dma_queue[index + 1];
    }

    dma_desc_t* first = &_dma_queue[0];
#if defined ( LGFX_PSRAM_DMA_CAPABLE )
    // Only the first external-RAM descriptor needs its head aligned to a DMA block.
    for (;;)
    {
      auto buf = (const uint8_t*)first->buffer;
      if (!buf || !esp_ptr_external_ram(buf)) { break; }
      uint32_t head = (uint32_t)(-(intptr_t)buf) & (dma_ext_align - 1);
      uint32_t len = first->dw0.length;
      if (_psram_dma_ok && head == 0 && len >= dma_ext_align) { break; }
      if (!_psram_dma_ok || head >= len || len - head < dma_ext_align)
      {
        // Send in register-sized pieces: a longer non-DMA writeBytes copies through
        // the flip buffer, which a later queued getDMABuffer() buffer may share.
        // Stage each piece so the word-rounded register copy stays in bounds.
        for (uint32_t pos = 0; pos < len; pos += 64)
        {
          uint32_t piece[16];
          uint32_t n = std::min<uint32_t>(len - pos, sizeof(piece));
          memcpy(piece, buf + pos, n);
          writeBytes((const uint8_t*)piece, n, true, false);
        }
        _dma_queue_bytes -= len;
        if (first->dw0.suc_eof) { _dma_queue_bytes = 0; return; }
        first = (dma_desc_t*)first->next;
        continue;
      }
      writeBytes(buf, head, true, false);
      first->buffer = const_cast<uint8_t*>(buf + head);
      len -= head;
      first->dw0.length = len;
      first->dw0.size = (len + 3) & ~3u;
      _dma_queue_bytes -= head;
      break;
    }
#endif

    std::swap(_dmadesc, _dma_queue);
    std::swap(_dmadesc_size, _dma_queue_capacity);
    dma_desc_fence();
#if defined ( CONFIG_IDF_TARGET_ESP32P4 )
    esp_cache_msync(_dmadesc, sizeof(dma_desc_t) * _dmadesc_size, ESP_CACHE_MSYNC_FLAG_DIR_C2M | ESP_CACHE_MSYNC_FLAG_UNALIGNED);
#endif

    dc_control(true);
    *_spi_dma_out_link_reg = 0;

#if defined ( SOC_GDMA_SUPPORTED ) && defined ( DMA_OUTLINK_START_CH0 )
    dma_channel_reset();
    auto dma = reg(SPI_DMA_CONF_REG(_spi_port));
#if defined ( SPI_DMA_AFIFO_RST ) && defined ( SPI_BUF_AFIFO_RST ) && defined ( SPI_RX_AFIFO_RST )
    *dma = SPI_DMA_AFIFO_RST | SPI_BUF_AFIFO_RST | SPI_RX_AFIFO_RST;
#endif
    #if defined ( CONFIG_IDF_TARGET_ESP32P4 ) || defined ( DMA_OUT_LINK_ADDR_CH0_REG )
    *_spi_dma_out_link2_reg = ((uint32_t)(first));
    *_spi_dma_out_link_reg = DMA_OUTLINK_START_CH0;
    #else
    *_spi_dma_out_link_reg = DMA_OUTLINK_START_CH0 | ((int)(first) & 0xFFFFF);
    #endif
    *dma = SPI_DMA_TX_ENA;
    _clear_dma_reg = dma;
    uint32_t len = ((_dma_queue_bytes - 1) & ((SPI_MS_DATA_BITLEN)>>3)) + 1;
    set_write_len(len << 3);
    // DMA準備完了待ち;
 #if defined ( DMA_OUTFIFO_EMPTY_CH0 )
    while (*_spi_dma_outstatus_reg & DMA_OUTFIFO_EMPTY_CH0 ) {}
 #endif
    exec_spi();

    uint32_t length = _dma_queue_bytes - len;
    _dma_queue_bytes = 0;
    if (length)
    {
      wait_spi();
      set_write_len(SPI_MS_DATA_BITLEN + 1);
      goto label_start;
      do
      {
        wait_spi();
label_start:
        exec_spi();
      } while (length -= ((SPI_MS_DATA_BITLEN + 1) >> 3));
    }
#elif defined ( CONFIG_IDF_TARGET_ESP32 ) || !defined ( CONFIG_IDF_TARGET )
    auto dma_conf_reg = reg(SPI_DMA_CONF_REG(_spi_port));
    auto dma_conf = *dma_conf_reg & ~(SPI_OUT_DATA_BURST_EN | SPI_AHBM_RST | SPI_AHBM_FIFO_RST | SPI_OUT_RST);
    dma_conf |= SPI_OUTDSCR_BURST_EN;
    *dma_conf_reg = dma_conf | SPI_AHBM_RST | SPI_AHBM_FIFO_RST | SPI_OUT_RST;
    *dma_conf_reg = dma_conf;

    *_spi_dma_out_link_reg = SPI_OUTLINK_START | ((int)(first) & 0xFFFFF);
    _clear_dma_reg = _spi_dma_out_link_reg;
    uint32_t len = _dma_queue_bytes;
    _dma_queue_bytes = 0;
    set_write_len(len << 3);
    // DMA準備完了待ち;
 #if defined (SPI_DMA_OUTFIFO_EMPTY)
    while (*_spi_dma_outstatus_reg & SPI_DMA_OUTFIFO_EMPTY ) {}
 #else
  #if defined ( LGFX_SPIDMA_WORKAROUND )
    if (_dma_ch) { spicommon_dmaworkaround_transfer_active(_dma_ch); }
  #endif
 #endif
    exec_spi();
#endif
  }

  void Bus_SPI::beginRead(uint_fast8_t dummy_bits)
  {
    beginRead();
    if (!dummy_bits) { return; }

#if defined ( SPI_UPDATE )  // for C3/S3

    /// ESP32-C3とS3は、1bitの送受信ができないため、CPOLの極性を反転させてダミークロックを生成する。;
    if (dummy_bits == 1)
    {
      auto pin_reg = reg(SPI_PIN_REG(_spi_port));
      auto cmd_reg = _spi_cmd_reg;
      auto value = *pin_reg;
      // 反転した極性が SPI クロック域へ届く前に元へ戻すと、クロックは 1 度も動かず読み出しが 1 bit ずれる。
      // 値を差し替える直前に、前の SPI_UPDATE (直前の beginRead() の分を含む) の完了 (自己クリア) を待つ。
      // 復帰後は待たない: 続く readData() の USR|UPDATE が同じ復帰値を載せる (他の転送と同じ契約)
      while (*cmd_reg & SPI_UPDATE) {}
      *pin_reg = value ^ SPI_CK_IDLE_EDGE;
      *cmd_reg = SPI_UPDATE;
      while (*cmd_reg & SPI_UPDATE) {}
      *pin_reg = value;
      *cmd_reg = SPI_UPDATE;
      return;
    }

#endif

    readData(dummy_bits);
  }

  void Bus_SPI::beginRead(void)
  {
    uint32_t pin = (_cfg.spi_mode & 2) ? SPI_CK_IDLE_EDGE : 0;
    uint32_t user = ((_cfg.spi_mode == 1 || _cfg.spi_mode == 2) ? SPI_CK_OUT_EDGE | SPI_USR_MISO : SPI_USR_MISO)
                        | (_cfg.spi_3wire ? SPI_SIO : 0);
    dc_control(true);
    *_spi_user_reg = user;
    writereg(SPI_PIN_REG(_spi_port), pin);
    writereg(SPI_CLOCK_REG(_spi_port), _clkdiv_read);
#if defined ( SPI_UPDATE )
    *_spi_cmd_reg = SPI_UPDATE;
#endif
  }

  void Bus_SPI::endRead(void)
  {
    uint32_t pin = (_cfg.spi_mode & 2) ? SPI_CK_IDLE_EDGE : 0;
    *_spi_user_reg = _user_reg;
    writereg(SPI_PIN_REG(_spi_port), pin);
    writereg(SPI_CLOCK_REG(_spi_port), _clkdiv_write);
#if defined ( SPI_UPDATE )
    *_spi_cmd_reg = SPI_UPDATE;
#endif
  }

  uint32_t Bus_SPI::readData(uint_fast8_t bit_length)
  {
    set_read_len(bit_length);
    auto spi_cmd_reg = _spi_cmd_reg;
    *spi_cmd_reg = SPI_EXECUTE;
    auto spi_w0_reg = _spi_w0_reg;
    uint32_t mask = (32 > bit_length) ? ~getSwap32((1 << (32 - bit_length))-1) : ~0;
    while (*spi_cmd_reg & SPI_USR);
    return *spi_w0_reg & mask;
  }

  bool Bus_SPI::readBytes(uint8_t* dst, uint32_t length, bool use_dma)
  {
#if defined ( SPI_DMA_IN_LINK_REG )
    if (_cfg.dma_channel && use_dma) {
      wait_spi();
      set_read_len(length << 3);

      auto dma_conf_reg = reg(SPI_DMA_CONF_REG(_spi_port));
      auto dma_conf = *dma_conf_reg & ~(SPI_AHBM_RST | SPI_AHBM_FIFO_RST | SPI_OUT_RST);
      *dma_conf_reg = dma_conf | SPI_AHBM_RST | SPI_AHBM_FIFO_RST | SPI_IN_RST;
      *dma_conf_reg = dma_conf | SPI_INDSCR_BURST_EN;

      _setup_dma_desc_links(dst, length);
      *reg(SPI_DMA_IN_LINK_REG(_spi_port)) = SPI_INLINK_START | ((int)(&_dmadesc[0]) & 0xFFFFF);
 #if defined ( LGFX_SPIDMA_WORKAROUND )
      if (_dma_ch) { spicommon_dmaworkaround_transfer_active(_dma_ch); }
 #endif
      exec_spi();
    }
    else
#endif
    {
      auto len1 = std::min<uint32_t>(length, 32u);  // 32 Byte read.
      auto len2 = len1;
      wait_spi();
      set_read_len(len1 << 3);
      exec_spi();

/// ESP32-C3 で HIGHPART を使用すると異常動作するため分岐する;
#if defined ( SPI_UPDATE )  // for C3/S3

      auto spi_w0_reg = _spi_w0_reg;
      do {
        if (0 == (length -= len1)) {
          len2 = len1;
          wait_spi();
          uint8_t tmp[32];
          memcpy(tmp, (void*)spi_w0_reg, (len2 + 3) & ~3u);
          memcpy(dst, tmp, len2);
        } else {
          if (length < len1) {
            len1 = length;
            wait_spi();
            set_read_len(len1 << 3);
          } else {
            wait_spi();
          }
          memcpy(dst, (void*)spi_w0_reg, (len2 + 3) & ~3u);
          exec_spi();
        }
        dst += len2;
      } while (length);

#else

      uint32_t userreg = *_spi_user_reg;
      uint32_t highpart = 8;
      auto spi_w0_reg = _spi_w0_reg;
      do {
        if (0 == (length -= len1)) {
          len2 = len1;
          wait_spi();
          *_spi_user_reg = userreg;
        } else {
          uint32_t user = userreg;
          if (highpart) user = userreg | SPI_USR_MISO_HIGHPART;
          if (length < len1) {
            len1 = length;
            wait_spi();
            set_read_len(len1 << 3);
          } else {
            wait_spi();
          }
          *_spi_user_reg = user;
          exec_spi();
        }
        memcpy(dst, (void*)&spi_w0_reg[highpart ^= 8], (len2+3)&~3u);
        dst += len2;
      } while (length);

#endif

    }
    return true;
  }

  void Bus_SPI::readPixels(void* dst, pixelcopy_t* param, uint32_t length)
  {
    auto len1 = std::min<uint32_t>(length, 10u);  // 10 pixel read
    auto len2 = len1;
    auto len_read_pixel = param->src_bits;
    uint32_t regbuf[8];
    wait_spi();
    set_read_len(len_read_pixel * len1);
    exec_spi();
    param->src_data = regbuf;
    int32_t dstindex = 0;
    auto spi_w0_reg = _spi_w0_reg;

/// ESP32-C3 で HIGHPART を使用すると異常動作するため分岐する;
#if defined ( SPI_UPDATE )  // for C3/S3

    do {
      if (0 == (length -= len1)) {
        len2 = len1;
        wait_spi();
        memcpy(regbuf, (void*)spi_w0_reg, ((len2 * len_read_pixel >> 3) + 3) & ~3);
      } else {
        if (length < len1) {
          len1 = length;
          wait_spi();
          set_read_len(len_read_pixel * len1);
        } else {
          wait_spi();
        }
        memcpy(regbuf, (void*)spi_w0_reg, ((len2 * len_read_pixel >> 3) + 3) & ~3);
        exec_spi();
      }
      param->src_x = 0;
      dstindex = param->fp_copy(dst, dstindex, dstindex + len2, param);
    } while (length);

#else

    uint32_t userreg = *_spi_user_reg;
    uint32_t highpart = 8;
    do {
      if (0 == (length -= len1)) {
        len2 = len1;
        wait_spi();
        *_spi_user_reg = userreg;
      } else {
        uint32_t user = userreg;
        if (highpart) user = userreg | SPI_USR_MISO_HIGHPART;
        if (length < len1) {
          len1 = length;
          wait_spi();
          set_read_len(len_read_pixel * len1);
        } else {
          wait_spi();
        }
        *_spi_user_reg = user;
        exec_spi();
      }
      memcpy(regbuf, (void*)&spi_w0_reg[highpart ^= 8], ((len2 * len_read_pixel >> 3)+3)&~3u);
      param->src_x = 0;
      dstindex = param->fp_copy(dst, dstindex, dstindex + len2, param);
    } while (length);

#endif

  }

  void Bus_SPI::_alloc_dmadesc(size_t len)
  {
    if (_dmadesc) heap_caps_free(_dmadesc);
    _dmadesc_size = len;
    _dmadesc = (dma_desc_t*)heap_caps_malloc(sizeof(dma_desc_t) * len, MALLOC_CAP_DMA);
  }

  void Bus_SPI::_spi_dma_reset(void)
  {
#if defined( SOC_GDMA_SUPPORTED )  // for C3/S3

#elif defined( CONFIG_IDF_TARGET_ESP32S2 )
    if (_cfg.spi_host == SPI2_HOST)
    {
      periph_module_reset( PERIPH_SPI2_DMA_MODULE );
    }
    else if (_cfg.spi_host == SPI3_HOST)
    {
      periph_module_reset( PERIPH_SPI3_DMA_MODULE );
    }
#elif defined( CONFIG_IDF_TARGET_ESP32 ) || !defined( CONFIG_IDF_TARGET )
 #if defined (PERIPH_SPI_DMA_MODULE)
    periph_module_reset( PERIPH_SPI_DMA_MODULE );
 #elif defined (PERIPH_HSPI_MODULE) && defined (PERIPH_VSPI_MODULE)
    if (_cfg.spi_host == SPI2_HOST)
    {
      periph_module_reset( PERIPH_HSPI_MODULE );
    }
    else
    {
      periph_module_reset( PERIPH_VSPI_MODULE );
    }
 #endif
#endif
  }

  void Bus_SPI::_setup_dma_desc_links(const uint8_t *data, int32_t len)
  {          //spicommon_setup_dma_desc_links
    if (!_cfg.dma_channel) return;

    if (_dmadesc_size * SPI_MAX_DMA_LEN < len)
    {
      _alloc_dmadesc(len / SPI_MAX_DMA_LEN + 1);
    }
    dma_desc_t *dmadesc = _dmadesc;

    while (len > SPI_MAX_DMA_LEN)
    {
      len -= SPI_MAX_DMA_LEN;
      dmadesc->buffer = (uint8_t *)data;
      data += SPI_MAX_DMA_LEN;
      *(uint32_t*)dmadesc = SPI_MAX_DMA_LEN | SPI_MAX_DMA_LEN << 12 | 0x80000000;
      dmadesc->next = dmadesc + 1;
      dmadesc++;
    }
    *(uint32_t*)dmadesc = ((len + 3) & ( ~3 )) | len << 12 | 0xC0000000;
    dmadesc->buffer = (uint8_t *)data;
    dmadesc->next = nullptr;
    dma_desc_fence();
  }

//----------------------------------------------------------------------------
 }
}

#endif
