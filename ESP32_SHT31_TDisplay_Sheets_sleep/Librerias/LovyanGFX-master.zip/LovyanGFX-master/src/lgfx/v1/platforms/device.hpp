/*----------------------------------------------------------------------------/
  Lovyan GFX - Graphics library for embedded devices.

Original Source:
 https://github.com/lovyan03/LovyanGFX/

Licence:
 [FreeBSD](https://github.com/lovyan03/LovyanGFX/blob/master/license.txt)

Author:
 [lovyan03](https://twitter.com/lovyan03)

Contributors:
 [ciniml](https://github.com/ciniml)
 [mongonta0716](https://github.com/mongonta0716)
 [tobozo](https://github.com/tobozo)
/----------------------------------------------------------------------------*/
#pragma once

#include "common.hpp"   // selects the platform; the desktop choice is recorded as LGFX_PLATFORM_*

#if defined (ESP_PLATFORM)

 #include <sdkconfig.h>

 #if defined (CONFIG_IDF_TARGET_ESP32C2)

  #include "esp32/Light_PWM.hpp"
  #include "esp32/Bus_SPI.hpp"
  #include "esp32/Bus_I2C.hpp"

 #elif defined (CONFIG_IDF_TARGET_ESP32C5)

  #include "esp32/Light_PWM.hpp"
  #include "esp32/Bus_SPI.hpp"
  #include "esp32/Bus_I2C.hpp"

 #elif defined (CONFIG_IDF_TARGET_ESP32C6)

  #include "esp32/Light_PWM.hpp"
  #include "esp32/Bus_SPI.hpp"
  #include "esp32/Bus_I2C.hpp"

 #elif defined (CONFIG_IDF_TARGET_ESP32C61)

  #include "esp32/Light_PWM.hpp"
  #include "esp32/Bus_SPI.hpp"
  #include "esp32/Bus_I2C.hpp"

 #elif defined (CONFIG_IDF_TARGET_ESP32C3)

  #include "esp32/Light_PWM.hpp"
  #include "esp32/Bus_SPI.hpp"
  #include "esp32/Bus_I2C.hpp"
  #include "esp32c3/Bus_Parallel8.hpp"

 #elif defined (CONFIG_IDF_TARGET_ESP32S2)

  #include "esp32/Light_PWM.hpp"
  #include "esp32/Bus_SPI.hpp"
  #include "esp32/Bus_I2C.hpp"
  #include "esp32s2/Bus_Parallel8.hpp"
  #include "esp32s2/Bus_Parallel16.hpp"

 #elif defined (CONFIG_IDF_TARGET_ESP32S3)

  #include "esp32/Light_PWM.hpp"
  #include "esp32/Bus_SPI.hpp"
  #include "esp32/Bus_I2C.hpp"
  #include "esp32s3/Bus_Parallel8.hpp"
  #include "esp32s3/Bus_Parallel16.hpp"

 #elif defined  (CONFIG_IDF_TARGET_ESP32P4)

  #include "esp32/Light_PWM.hpp"
  #include "esp32/Bus_SPI.hpp"
  #include "esp32/Bus_I2C.hpp"
  #include "esp32p4/Bus_DSI.hpp"
  #include "esp32/Bus_Parallel8.hpp"
  #include "esp32/Bus_HUB75.hpp"

 #elif defined (CONFIG_IDF_TARGET_ESP32H2)

  #include "esp32/Light_PWM.hpp"
  #include "esp32/Bus_SPI.hpp"
  #include "esp32/Bus_I2C.hpp"

 #else

  #include "esp32/Light_PWM.hpp"
  #include "esp32/Bus_SPI.hpp"
  #include "esp32/Bus_I2C.hpp"
  #include "esp32/Bus_Parallel8.hpp"
  #include "esp32/Bus_HUB75.hpp"
  #include "esp32/Panel_CVBS.hpp"

 #endif

#elif defined (ESP8266)

#include "esp8266/Bus_SPI.hpp"
#include "esp8266/Bus_I2C.hpp"

#elif defined (__SAMD21__) || defined(__SAMD21G18A__) || defined(__SAMD21J18A__) || defined(__SAMD21E17A__) || defined(__SAMD21E18A__)

#include "samd21/Bus_SPI.hpp"
#include "samd21/Bus_I2C.hpp"

#elif defined (__SAMD51__)

#include "samd51/Bus_SPI.hpp"
#include "samd51/Bus_I2C.hpp"

#elif defined (STM32F2xx) || defined (STM32F4xx) || defined (STM32F7xx)

#include "stm32/Bus_SPI.hpp"

#elif defined (ARDUINO_ARCH_SPRESENSE)

#include "spresense/Bus_SPI.hpp"

#elif defined (ARDUINO_ARCH_MBED_RP2040) || defined(ARDUINO_ARCH_RP2040) || defined(USE_PICO_SDK)

#include "rp2040/Light_PWM.hpp"
#include "rp2040/Bus_I2C.hpp"
#include "rp2040/Bus_SPI.hpp"

#elif defined (ARDUINO)

#include "arduino_default/Bus_SPI.hpp"

#elif defined (LGFX_PLATFORM_SDL)   // chosen by platforms/common.hpp

#include "sdl/Bus_I2C.hpp"
#include "sdl/Panel_sdl.hpp"

#endif
