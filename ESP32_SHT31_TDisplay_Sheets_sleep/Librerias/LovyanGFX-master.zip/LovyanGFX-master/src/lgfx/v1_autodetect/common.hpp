/*----------------------------------------------------------------------------/
  Lovyan GFX - Graphics library for embedded devices.

Original Source:
 https://github.com/lovyan03/LovyanGFX/

Licence:
 [FreeBSD](https://github.com/lovyan03/LovyanGFX/blob/master/license.txt)

Author:
 [lovyan03](https://twitter.com/lovyan03)

Contributors:
 [ciniml](https://github.com/ciniml)
 [mongonta0716](https://github.com/mongonta0716)
 [tobozo](https://github.com/tobozo)
/----------------------------------------------------------------------------*/
#pragma once

#ifndef LGFX_USE_V1
#define LGFX_USE_V1
#endif

#include "LovyanGFX.hpp"

#if defined (ESP_PLATFORM)

 #include <sdkconfig.h>

 #include "LGFX_AutoDetect_ESP32_all.hpp"

#elif defined (ESP8266)

 #include "LGFX_AutoDetect_ESP8266.hpp"

#elif defined (__SAMD21__) || defined(__SAMD21G18A__) || defined(__SAMD21J18A__) || defined(__SAMD21E17A__) || defined(__SAMD21E18A__)

 #include "LGFX_AutoDetect_SAMD21.hpp"

#elif defined (__SAMD51__)

 #include "LGFX_AutoDetect_SAMD51.hpp"

#elif defined (STM32F2xx) || defined (STM32F4xx) || defined (STM32F7xx)

  #include "LGFX_AutoDetect_STM32.hpp"

// Desktop: follow the back end chosen by lgfx/v1/platforms/common.hpp (included through LovyanGFX.hpp above).
#elif defined (LGFX_PLATFORM_SDL)

  #include "LGFX_AutoDetect_sdl.hpp"

#elif defined (LGFX_PLATFORM_OPENCV)

  #include "LGFX_AutoDetect_OpenCV.hpp"

#elif defined (LGFX_PLATFORM_FRAMEBUFFER)

  #include "LGFX_AutoDetect_FrameBuffer.hpp"

#endif
